import { Images } from "assets/images";

export const Data_MealRecipes = [
  {
    id: 0,
    name: "pizza",
    image: Images.pizzaBf,
    cals: 328,
  },
  {
    id: 1,
    name: "donut",
    image: Images.donutBf,
    cals: 328,
  },
  {
    id: 2,
    name: "pizza",
    image: Images.pizzaBf,
    cals: 328,
  },
];

export interface ReportType {
  name?: string;
  income?: number;
  totalIncome?: number;
  expense?: number;
  totalExpense?: number;
}

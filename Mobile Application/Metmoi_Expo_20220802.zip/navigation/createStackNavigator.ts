import { createNativeStackNavigator } from "@react-navigation/native-stack";

export default createNativeStackNavigator;

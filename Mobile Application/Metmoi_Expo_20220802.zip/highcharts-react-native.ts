declare module "@highcharts/highcharts-react-native";
